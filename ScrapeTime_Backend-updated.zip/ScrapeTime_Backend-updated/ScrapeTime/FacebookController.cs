using ScrapeTime.Domain;
using ScrapeTime.Services;

namespace ScrapeTime.Controllers;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Threading.Tasks;

[Route("api/[controller]")]
[ApiController]
public class FacebookController : ControllerBase
{
    private readonly FacebookService _facebookService;

    public FacebookController(IOptions<FacebookSettings> settings)
    {
        _facebookService = new FacebookService(settings.Value.AccessToken);
    }

    [HttpGet("most-liked-posts")]
    public async Task<IActionResult> GetMostLikedPosts(string pageId, int limit = 10)
    {
        if (string.IsNullOrEmpty(pageId))
        {
            return BadRequest("Page ID is required.");
        }

        var posts = await _facebookService.GetMostLikedPostsAsync(pageId, limit);
        return Ok(posts);
    }
}

using Newtonsoft.Json.Linq;
using RestSharp;

namespace ScrapeTime.Services
{
    public class FacebookService
    {
        private readonly string _accessToken;

        public FacebookService(string accessToken)
        {
            _accessToken = accessToken;
        }

        public async Task<IEnumerable<dynamic>> GetMostLikedPostsAsync(string pageId, int limit = 10)
        {
            var client = new RestClient("https://graph.facebook.com");
            var request = new RestRequest($"/{pageId}/posts", Method.Get);
            request.AddParameter("fields", "message,likes.summary(true)");
            request.AddParameter("limit", limit);
            request.AddParameter("access_token", _accessToken);

            var response = await client.ExecuteAsync(request);
            var result = JObject.Parse(response.Content);

            var posts = new List<dynamic>();
            foreach (var post in result["data"])
            {
                var message = post["message"]?.ToString();
                var likes = (int?)post["likes"]?["summary"]?["total_count"] ?? 0;
                posts.Add(new
                {
                    Message = message,
                    Likes = likes
                });
            }

            return posts;
        }
    }
}